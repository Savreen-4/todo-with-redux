import React from "react";

function Page (){
    return(
        <div>
            <h4>Page here</h4>
        </div>
    )
}
export default Page