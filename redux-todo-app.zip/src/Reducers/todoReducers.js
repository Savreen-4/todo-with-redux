const initialData = {
    list:[],
};

const todoReducers=(state=initialData,action)=>{
    switch (action.type){
        case "ADD_TODO":
            console.log(action,'action to add')
            const {data,id} = action.payload;
            return {
                ...state,
                list:[
                    ...state.list,
                    {
                        id:id,
                        data:data
                    }
                ]
            }

            

            case "DELETE_TODO":
                console.timeLog(action.id,'id action')
            const filterDeleteTodo = state.list.filter((elem)=>elem.id !== action.id);
            console.log(filterDeleteTodo,'filterDeleteTodo')
            return{
                ...state,
                list:filterDeleteTodo
            }



            case "REMOVE_TODO":
            return{
                ...state,
                list:[]
            }


            default:
                return state;


    }
}
export default todoReducers;