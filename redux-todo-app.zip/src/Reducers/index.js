import todoReducers from './todoReducers';

import { combineReducers } from 'redux';

const rootReducers = combineReducers({
    todoReducers
})
export default rootReducers